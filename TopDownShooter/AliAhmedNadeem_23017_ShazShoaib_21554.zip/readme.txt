Ali Ahmed Nadeem - 23017
- coded player and enemies (all classes except Smoke and Explosion)
Shaz Shoaib - 21554
- coded UI and Particles